# ===========================================
# WORDLE GAME - Script de Gestion para Windows PowerShell
# ===========================================

$ErrorActionPreference = "Stop"

$COMPOSE_FILE = "docker-compose.yml"
$PROJECT_NAME = "wordle"

function Show-Help {
    Write-Host @"
WORDLE GAME - Gestion de Contenedores

Uso: .\wordle.ps1 <comando>

Comandos disponibles:
  start       - Inicia el juego
  stop        - Detiene el juego
  restart     - Reinicia el juego
  status      - Muestra el estado
  logs        - Muestra los logs
  rebuild     - Reconstruye las imagenes
  clean       - Limpia todo (incluidos datos!)
  backup      - Hace copia de seguridad
  restore     - Restaura copia de seguridad
  help        - Muestra esta ayuda

Ejemplos:
  .\wordle.ps1 start
  .\wordle.ps1 logs
  .\wordle.ps1 backup

"@
}

function Start-Game {
    Write-Host "Iniciando Wordle Game..." -ForegroundColor Green
    
    # Limpiar contenedores antiguos primero
    $oldContainers = docker ps -a --filter "name=wordle" --format "{{.Names}}" 2>$null
    if ($oldContainers) {
        Write-Host "   Limpiando contenedores antiguos..." -ForegroundColor Yellow
        foreach ($container in $oldContainers) {
            docker rm -f $container | Out-Null
        }
    }
    
    docker compose -f $COMPOSE_FILE up -d --build
    Write-Host "[OK] Juego iniciado" -ForegroundColor Green
    Write-Host ""
    Write-Host "Accede a: http://localhost" -ForegroundColor Cyan
}

function Stop-Game {
    Write-Host "Deteniendo Wordle Game..." -ForegroundColor Yellow
    docker compose -f $COMPOSE_FILE down
    Write-Host "[OK] Juego detenido" -ForegroundColor Green
}

function Restart-Game {
    Write-Host "Reiniciando Wordle Game..." -ForegroundColor Cyan
    docker compose -f $COMPOSE_FILE restart
    Write-Host "[OK] Juego reiniciado" -ForegroundColor Green
}

function Show-Status {
    Write-Host "Estado del Wordle Game:" -ForegroundColor Cyan
    Write-Host ""
    docker compose -f $COMPOSE_FILE ps
    Write-Host ""
    Write-Host "Volumenes:" -ForegroundColor Cyan
    docker volume ls | Select-String "wordle" | ForEach-Object { Write-Host $_ }
    if (-not (docker volume ls | Select-String "wordle")) {
        Write-Host "  No se encontro ningun volumen" -ForegroundColor Gray
    }
}

function Show-Logs {
    docker compose -f $COMPOSE_FILE logs -f --tail=50
}

function Rebuild-Game {
    Write-Host "Reconstruyendo imagenes..." -ForegroundColor Cyan
    docker compose -f $COMPOSE_FILE down
    docker compose -f $COMPOSE_FILE up -d --build --force-recreate
    Write-Host "[OK] Imagenes reconstruidas" -ForegroundColor Green
}

function Clean-All {
    Write-Host "LIMPIEZA COMPLETA - Se perderan todos los datos" -ForegroundColor Red
    $confirm = Read-Host "Estas seguro? (s/N)"
    if ($confirm -eq "s" -or $confirm -eq "S") {
        docker compose -f $COMPOSE_FILE down -v
        docker volume rm wordle_postgres_data -ErrorAction SilentlyContinue
        Write-Host "[OK] Limpieza completada" -ForegroundColor Green
    } else {
        Write-Host "Cancelado" -ForegroundColor Yellow
    }
}

function Backup-Db {
    $timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
    $BACKUP_FILE = "backups/wordle_backup_$timestamp.sql"
    
    if (-not (Test-Path "backups")) {
        New-Item -ItemType Directory -Path "backups" | Out-Null
    }
    
    Write-Host "Haciendo copia de seguridad..." -ForegroundColor Cyan
    docker exec wordle-db pg_dump -U wordleuser wordledb > $BACKUP_FILE
    Write-Host "[OK] Copia creada: $BACKUP_FILE" -ForegroundColor Green
}

function Restore-Db {
    param([string]$backupFile)
    
    if ([string]::IsNullOrEmpty($backupFile)) {
        Write-Host "Especifica el archivo de backup:" -ForegroundColor Red
        Write-Host "   .\wordle.ps1 restore backups/wordle_backup_20240101.sql" -ForegroundColor Yellow
        exit 1
    }
    
    if (-not (Test-Path $backupFile)) {
        Write-Host "El archivo no existe: $backupFile" -ForegroundColor Red
        exit 1
    }
    
    Write-Host "Restaurando backup: $backupFile" -ForegroundColor Cyan
    Get-Content $backupFile | docker exec -i wordle-db psql -U wordleuser wordledb
    Write-Host "[OK] Backup restaurado" -ForegroundColor Green
}

# Main
$command = $args[0]

switch ($command) {
    "start" { Start-Game }
    "stop" { Stop-Game }
    "restart" { Restart-Game }
    "status" { Show-Status }
    "logs" { Show-Logs }
    "rebuild" { Rebuild-Game }
    "clean" { Clean-All }
    "backup" { Backup-Db }
    "restore" { 
        if ($args[1]) {
            Restore-Db -backupFile $args[1]
        } else {
            Write-Host "Especifica el archivo de backup:" -ForegroundColor Red
            Write-Host "   .\wordle.ps1 restore backups/wordle_backup_20240101.sql" -ForegroundColor Yellow
            exit 1
        }
    }
    "help" { Show-Help }
    "--help" { Show-Help }
    "-h" { Show-Help }
    default { 
        if ([string]::IsNullOrEmpty($command)) {
            Show-Help
        } else {
            Write-Host "Comando desconocido: $command" -ForegroundColor Red
            Show-Help
            exit 1
        }
    }
}
