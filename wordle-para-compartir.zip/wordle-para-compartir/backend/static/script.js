/**
 * Wordle Game - Frontend JavaScript
 * ===================================
 * Lógica del juego Wordle con autenticación y estadísticas
 */

// ============================================================================
// ESTADO GLOBAL
// ============================================================================

const GameState = {
    currentUser: null,
    currentGameWord: null,
    currentAttempt: 0,
    maxAttempts: 6,
    wordLength: 5,
    currentGuess: '',
    keyboardListenerActive: false
};

const CONFIG = {
    API: {
        REGISTER: '/register',
        TOKEN: '/token',
        GAME_START: '/api/game/start',
        GAME_GUESS: '/api/game/guess',
        SCORES: '/api/scores',
        STATS: '/api/stats',
        SCORES_CLEAR: '/api/scores/clear'
    },
    STORAGE: {
        TOKEN: 'token',
        USERNAME: 'username'
    }
};

// ============================================================================
// UTILIDADES
// ============================================================================

/**
 * Obtiene el token almacenado en localStorage
 */
function getToken() {
    return localStorage.getItem(CONFIG.STORAGE.TOKEN);
}

/**
 * Realiza una petición fetch con autenticación
 */
async function fetchWithAuth(url, options = {}) {
    const token = getToken();
    const headers = {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`,
        ...(options.headers || {})
    };

    const response = await fetch(url, { ...options, headers });
    return response.json();
}

/**
 * Muestra mensaje de error en rojo
 */
function showError(elementId, message) {
    const messageEl = document.getElementById(elementId);
    if (!messageEl) return;
    
    messageEl.className = 'message error';
    messageEl.textContent = message;
    messageEl.style.display = 'block';
}

/**
 * Muestra mensaje de éxito en verde
 */
function showSuccess(elementId, message) {
    const messageEl = document.getElementById(elementId);
    if (!messageEl) return;
    
    messageEl.className = 'message success';
    messageEl.textContent = message;
    messageEl.style.display = 'block';
}

/**
 * Limpia todos los mensajes
 */
function clearMessages() {
    ['login-message', 'register-message'].forEach(id => {
        const el = document.getElementById(id);
        if (el) {
            el.className = 'message';
            el.textContent = '';
            el.style.display = 'none';
        }
    });
}

// ============================================================================
// AUTENTICACIÓN
// ============================================================================

function showRegister() {
    document.getElementById('login-form').style.display = 'none';
    document.getElementById('register-form').style.display = 'block';
    clearMessages();
}

function showLogin() {
    document.getElementById('register-form').style.display = 'none';
    document.getElementById('login-form').style.display = 'block';
    clearMessages();
}

async function handleLogin(event) {
    event.preventDefault();

    const username = document.getElementById('login-username').value.trim();
    const password = document.getElementById('login-password').value;

    if (!username || !password) {
        showError('login-message', '❌ Por favor, completa todos los campos');
        return;
    }

    // Limpiar mensaje de registro
    const regMsg = document.getElementById('register-message');
    if (regMsg) {
        regMsg.className = 'message';
        regMsg.textContent = '';
        regMsg.style.display = 'none';
    }

    try {
        const formData = new URLSearchParams();
        formData.append('username', username);
        formData.append('password', password);

        const response = await fetch(CONFIG.API.TOKEN, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: formData.toString()
        });

        const data = await response.json();

        if (response.ok && data.access_token) {
            localStorage.setItem(CONFIG.STORAGE.TOKEN, data.access_token);
            localStorage.setItem(CONFIG.STORAGE.USERNAME, username);
            GameState.currentUser = username;

            // Limpiar formulario
            document.getElementById('login-username').value = '';
            document.getElementById('login-password').value = '';

            showSuccess('login-message', '✅ ¡Inicio de sesión exitoso!');

            setTimeout(() => showGameSection(), 800);
        } else {
            const detail = data.detail || 'Error desconocido';
            const errorMessages = {
                'Contraseña': '❌ Contraseña incorrecta',
                'incorrecta': '❌ Contraseña incorrecta',
                'Usuario': '❌ Usuario no encontrado',
                'no encontrado': '❌ Usuario no encontrado',
                'Too many': '⏰ Demasiados intentos. Espera 5 minutos',
                'intentos': '⏰ Demasiados intentos. Espera 5 minutos',
                'disabled': '❌ Cuenta desactivada',
                'desactivada': '❌ Cuenta desactivada'
            };

            let errorMessage = '❌ Error: ' + detail;
            for (const [key, msg] of Object.entries(errorMessages)) {
                if (detail.includes(key)) {
                    errorMessage = msg;
                    break;
                }
            }
            showError('login-message', errorMessage);
        }
    } catch (error) {
        console.error('Login error:', error);
        showError('login-message', '❌ Error de conexión. Verifica el servidor');
    }
}

async function handleRegister(event) {
    event.preventDefault();

    const username = document.getElementById('register-username').value.trim();
    const password = document.getElementById('register-password').value;

    // Validaciones
    if (!username || !password) {
        showError('register-message', '❌ Por favor, completa todos los campos');
        return;
    }

    if (username.length < 3) {
        showError('register-message', '❌ El usuario debe tener al menos 3 caracteres');
        return;
    }

    if (password.length < 4) {
        showError('register-message', '❌ La contraseña debe tener al menos 4 caracteres');
        return;
    }

    if (!/^[a-zA-Z0-9_]+$/.test(username)) {
        showError('register-message', '❌ Usuario solo puede contener letras, números y guiones bajos');
        return;
    }

    // Limpiar mensaje de login
    const loginMsg = document.getElementById('login-message');
    if (loginMsg) {
        loginMsg.className = 'message';
        loginMsg.textContent = '';
        loginMsg.style.display = 'none';
    }

    try {
        const response = await fetch(CONFIG.API.REGISTER, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, password })
        });

        const data = await response.json();

        if (response.ok) {
            showSuccess('register-message', '✅ ¡Usuario creado correctamente! Inicia sesión ahora');

            document.getElementById('register-username').value = '';
            document.getElementById('register-password').value = '';

            setTimeout(() => {
                showLogin();
                document.getElementById('login-username').value = username;
                document.getElementById('login-password').focus();
            }, 2000);
        } else {
            const detail = data.detail || 'Error al registrar';
            const message = detail.includes('already exists') || detail.includes('ya existe')
                ? '❌ Este usuario ya existe. Elige otro'
                : '❌ ' + detail;
            showError('register-message', message);
        }
    } catch (error) {
        console.error('Register error:', error);
        showError('register-message', '❌ Error de conexión. Verifica el servidor');
    }
}

function logoutUser() {
    localStorage.removeItem(CONFIG.STORAGE.TOKEN);
    localStorage.removeItem(CONFIG.STORAGE.USERNAME);
    GameState.currentUser = null;
    showAuthSection();
}

// ============================================================================
// GESTIÓN DE SECCIONES
// ============================================================================

function showAuthSection() {
    document.getElementById('auth-section').style.display = 'block';
    document.getElementById('game-section').style.display = 'none';
    clearMessages();
}

function showGameSection() {
    document.getElementById('auth-section').style.display = 'none';
    document.getElementById('game-section').style.display = 'block';
    document.getElementById('current-username').textContent = GameState.currentUser;
    initGame();
}

// ============================================================================
// JUEGO - INICIALIZACIÓN
// ============================================================================

async function initGame() {
    GameState.currentAttempt = 0;
    GameState.currentGameWord = null;
    GameState.currentGuess = '';

    // Crear tablero
    const gameBoard = document.getElementById('game-board');
    gameBoard.innerHTML = '';

    for (let i = 0; i < GameState.maxAttempts; i++) {
        for (let j = 0; j < GameState.wordLength; j++) {
            const tile = document.createElement('div');
            tile.className = 'tile';
            tile.id = `tile-${i}-${j}`;
            gameBoard.appendChild(tile);
        }
    }

    showKeyboard();
    setupPhysicalKeyboard();
    await loadWordOfTheDay();
    loadScores();
}

function showKeyboard() {
    const keyboard = document.getElementById('keyboard');
    keyboard.innerHTML = '';

    const rows = [
        ['Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P'],
        ['A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L'],
        ['ENTER', 'Z', 'X', 'C', 'V', 'B', 'N', 'M', '⌫']
    ];

    rows.forEach(row => {
        row.forEach(key => {
            const button = document.createElement('button');
            button.className = 'key';
            button.setAttribute('data-key', key);
            if (key === 'ENTER' || key === '⌫') {
                button.classList.add('wide');
            }
            button.textContent = key;
            button.onclick = () => handleKeyPress(key);
            keyboard.appendChild(button);
        });
    });
}

// ============================================================================
// JUEGO - TECLADO FÍSICO
// ============================================================================

function setupPhysicalKeyboard() {
    if (GameState.keyboardListenerActive) return;
    
    document.addEventListener('keydown', handlePhysicalKeyPress);
    GameState.keyboardListenerActive = true;
}

function handlePhysicalKeyPress(event) {
    // Ignorar si no estamos en el juego
    if (document.getElementById('game-section').style.display === 'none') return;
    
    // Ignorar si el foco está en un input
    if (event.target.tagName === 'INPUT' || event.target.tagName === 'TEXTAREA') return;
    
    const key = event.key.toUpperCase();
    
    if (/^[A-Z]$/.test(key) && key.length === 1) {
        event.preventDefault();
        handleKeyPress(key);
    } else if (key === 'ENTER') {
        event.preventDefault();
        handleKeyPress('ENTER');
    } else if (key === 'BACKSPACE' || key === 'DELETE') {
        event.preventDefault();
        handleKeyPress('⌫');
    }
}

// ============================================================================
// JUEGO - LÓGICA
// ============================================================================

function handleKeyPress(key) {
    if (key === 'ENTER') {
        submitGuess();
    } else if (key === '⌫') {
        GameState.currentGuess = GameState.currentGuess.slice(0, -1);
        updateCurrentRow();
    } else if (GameState.currentGuess.length < GameState.wordLength && /^[A-Z]$/.test(key)) {
        GameState.currentGuess += key;
        updateCurrentRow();
    }
}

function updateCurrentRow() {
    for (let j = 0; j < GameState.wordLength; j++) {
        const tile = document.getElementById(`tile-${GameState.currentAttempt}-${j}`);
        if (tile) {
            tile.textContent = GameState.currentGuess[j] || '';
            tile.className = GameState.currentGuess[j] ? 'tile active' : 'tile';
        }
    }
}

async function submitGuess() {
    if (GameState.currentGuess.length !== GameState.wordLength) {
        showMessage('La palabra debe tener 5 letras', 'error');
        return;
    }

    if (!GameState.currentGameWord) {
        showMessage('Error: No hay palabra cargada', 'error');
        return;
    }

    try {
        const data = await fetchWithAuth(CONFIG.API.GAME_GUESS, {
            method: 'POST',
            body: JSON.stringify({
                guess: GameState.currentGuess,
                current_game_word: GameState.currentGameWord,
                attempt_number: GameState.currentAttempt + 1
            })
        });

        if (data.result) {
            updateBoard(data.result);
            updateKeyboard(data.result);

            if (data.won) {
                showMessage(`🎉 ¡Felicidades! Has acertado en ${GameState.currentAttempt + 1} intentos`, 'success');
                setTimeout(() => loadScores(), 2000);
                GameState.currentGuess = '';
                return;
            }

            GameState.currentAttempt++;
            GameState.currentGuess = '';

            if (GameState.currentAttempt >= GameState.maxAttempts) {
                showMessage(`😔 Fin del juego. La palabra era: ${GameState.currentGameWord}`, 'error');
                setTimeout(() => loadScores(), 3000);
            }
        } else if (data.detail) {
            showMessage(data.detail, 'error');
        }
    } catch (error) {
        console.error('Submit guess error:', error);
        showMessage('Error de conexión', 'error');
    }
}

function updateBoard(result) {
    for (let j = 0; j < GameState.wordLength; j++) {
        const tile = document.getElementById(`tile-${GameState.currentAttempt}-${j}`);
        if (tile) {
            tile.className = `tile ${result[j]}`;
        }
    }
}

function updateKeyboard(result) {
    for (let j = 0; j < GameState.wordLength; j++) {
        const letter = GameState.currentGuess[j];
        const keyButton = document.querySelector(`.key[data-key="${letter}"]`);
        
        if (keyButton) {
            const newClass = result[j];
            const currentClass = keyButton.classList.contains('correct') ? 'correct'
                : keyButton.classList.contains('present') ? 'present'
                : keyButton.classList.contains('absent') ? 'absent' : null;
            
            // Solo actualizar si el nuevo estado es más importante
            if (newClass === 'correct' || (!currentClass && newClass) || 
                (currentClass === 'absent' && newClass === 'present')) {
                keyButton.className = `key ${newClass}`;
            }
        }
    }
}

async function loadWordOfTheDay() {
    try {
        const data = await fetchWithAuth(CONFIG.API.GAME_START);
        
        if (data.word) {
            GameState.currentGameWord = data.word;
            showMessage('¡Nueva partida iniciada! Tienes 6 intentos.', 'info');
        } else {
            showMessage('Error al cargar la palabra', 'error');
        }
    } catch (error) {
        console.error('Error loading word:', error);
        showMessage('Error de conexión', 'error');
    }
}

function showMessage(message, type = 'info') {
    const messageArea = document.getElementById('message-area');
    if (!messageArea) return;
    
    messageArea.textContent = message;
    messageArea.className = `game-message ${type}`;

    if (type !== 'error') {
        setTimeout(() => {
            messageArea.textContent = '';
            messageArea.className = 'game-message';
        }, 3000);
    }
}

// ============================================================================
// PUNTUACIONES Y ESTADÍSTICAS
// ============================================================================

async function loadScores() {
    try {
        const scores = await fetchWithAuth(CONFIG.API.SCORES);
        const scoresList = document.getElementById('scores-list');
        if (!scoresList) return;

        if (scores.length === 0) {
            scoresList.innerHTML = '<p>No hay partidas registradas</p>';
        } else {
            scoresList.innerHTML = scores.map(score => {
                const timeStr = score.timestamp 
                    ? new Date(score.timestamp).toLocaleString('es-ES', {
                        day: '2-digit', month: '2-digit', year: 'numeric',
                        hour: '2-digit', minute: '2-digit'
                    })
                    : score.date;
                
                if (score.won) {
                    return `<p class="score-won">
                        ✅ ¡Ganaste en ${score.attempts} intentos!
                        <br><small>Palabra: <strong>${score.guessed_word || score.game_word}</strong> | ${timeStr}</small>
                    </p>`;
                } else {
                    return `<p class="score-lost">
                        ❌ Perdiste
                        <br><small>Palabra correcta: <strong>${score.game_word}</strong> | ${timeStr}</small>
                    </p>`;
                }
            }).join('');
        }
        
        loadStats();
    } catch (error) {
        console.error('Load scores error:', error);
    }
}

async function loadStats() {
    try {
        const stats = await fetchWithAuth(CONFIG.API.STATS);
        const statsContainer = document.getElementById('stats-container');
        if (!statsContainer) return;
        
        statsContainer.innerHTML = `
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-value">${stats.total_games}</div>
                    <div class="stat-label">Partidas Jugadas</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value">${stats.won}</div>
                    <div class="stat-label">Partidas Ganadas</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value">${stats.lost}</div>
                    <div class="stat-label">Partidas Perdidas</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value">${stats.win_percentage}%</div>
                    <div class="stat-label">Porcentaje de Victorias</div>
                </div>
            </div>
        `;
    } catch (error) {
        console.error('Load stats error:', error);
    }
}

async function resetGameForToday() {
    GameState.currentAttempt = 0;
    GameState.currentGuess = '';
    GameState.currentGameWord = null;

    // Limpiar tablero
    document.querySelectorAll('.tile').forEach(tile => {
        tile.textContent = '';
        tile.className = 'tile';
    });

    // Limpiar teclado
    document.querySelectorAll('.key').forEach(key => {
        key.className = 'key';
    });

    await loadWordOfTheDay();
    showMessage('Nueva partida iniciada', 'info');
}

async function clearScores() {
    if (!confirm('¿Estás seguro de que quieres borrar tu historial?')) return;

    try {
        await fetchWithAuth(CONFIG.API.SCORES_CLEAR, { method: 'DELETE' });
        showMessage('Historial borrado', 'success');
        loadScores();
    } catch (error) {
        console.error('Clear scores error:', error);
        showMessage('Error al borrar historial', 'error');
    }
}

// ============================================================================
// INICIALIZACIÓN
// ============================================================================

document.addEventListener('DOMContentLoaded', () => {
    const savedUsername = localStorage.getItem(CONFIG.STORAGE.USERNAME);
    const savedToken = localStorage.getItem(CONFIG.STORAGE.TOKEN);

    if (savedUsername && savedToken) {
        GameState.currentUser = savedUsername;
        showGameSection();
    } else {
        showAuthSection();
    }
});
