"""
Wordle Game Backend - FastAPI Application
==========================================
Juego Wordle con autenticación JWT, PostgreSQL y Docker.
"""

from fastapi import FastAPI, Depends, HTTPException, status, Request
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from sqlalchemy import create_engine, Column, Integer, String, Date, DateTime, func, Boolean, Index
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, Session
from pydantic import BaseModel, Field, validator
from datetime import date, timedelta, datetime, timezone
from typing import List, Optional
from contextlib import asynccontextmanager
import bcrypt
import random
import os
import re
from jose import JWTError, jwt

# ============================================================================
# CONFIGURACIÓN
# ============================================================================

# Word Lists
VALID_WORDS: set = set()
WORD_OF_DAY_POOL: List[str] = []
WORD_LIST_PATH = os.path.join(
    os.path.dirname(os.path.abspath(__file__)),
    "data",
    "wordle_words.txt"
)

# Database
DATABASE_URL = os.getenv(
    "DATABASE_URL",
    "postgresql://wordleuser:wordlepassword@db:5432/wordledb"
)

# Security
SECRET_KEY = os.getenv(
    "SECRET_KEY",
    "09d25e094faa6ca2556c818166b7a9563b93f7099f6f0f4a27521796c342f561"
)
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60 * 24  # 24 horas

# Rate Limiting
MAX_FAILED_ATTEMPTS = 5
LOCKOUT_TIME_SECONDS = 300  # 5 minutos
failed_logins: dict = {}

# Game Constants
WORD_LENGTH = 5
MAX_ATTEMPTS = 6


# ============================================================================
# FUNCIONES AUXILIARES
# ============================================================================

def load_words_from_file(file_path: str) -> List[str]:
    """Carga palabras desde un archivo, una por línea."""
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            words = [line.strip().upper() for line in f if line.strip()]
        return words
    except FileNotFoundError:
        print(f"ERROR: Word list not found at {file_path}")
        return []
    except Exception as e:
        print(f"ERROR loading words: {e}")
        return []


def verify_password(plain_password: str, hashed_password: str) -> bool:
    """Verifica si una contraseña coincide con su hash."""
    try:
        return bcrypt.checkpw(
            plain_password.encode('utf-8'),
            hashed_password.encode('utf-8')
        )
    except Exception:
        return False


def get_password_hash(password: str) -> str:
    """Genera hash bcrypt para una contraseña."""
    return bcrypt.hashpw(
        password[:72].encode('utf-8'),
        bcrypt.gensalt()
    ).decode('utf-8')


# ============================================================================
# LIFESPAN - Startup/Shutdown
# ============================================================================

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Gestiona el ciclo de vida de la aplicación."""
    # Startup
    global VALID_WORDS, WORD_OF_DAY_POOL
    VALID_WORDS = set(load_words_from_file(WORD_LIST_PATH))
    WORD_OF_DAY_POOL = list(VALID_WORDS)
    print(f"✅ Loaded {len(VALID_WORDS)} words")
    
    # Crear tablas
    Base.metadata.create_all(bind=engine)
    print("✅ Database tables created")
    
    yield
    
    # Shutdown
    print("👋 Shutting down...")
    failed_logins.clear()


# ============================================================================
# APLICACIÓN FASTAPI
# ============================================================================

app = FastAPI(
    title="Wordle Game API",
    description="Juego Wordle con autenticación y estadísticas",
    version="2.1.0",
    lifespan=lifespan
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Static files
app.mount("/static", StaticFiles(directory="static"), name="static")

# Templates
templates = Jinja2Templates(directory="templates")


# ============================================================================
# BASE DE DATOS
# ============================================================================

engine = create_engine(
    DATABASE_URL,
    pool_pre_ping=True,
    pool_size=10,
    max_overflow=20
)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


class User(Base):
    __tablename__ = "users"
    
    id = Column(Integer, primary_key=True, index=True)
    username = Column(String, unique=True, index=True, nullable=False)
    hashed_password = Column(String, nullable=False)
    created_at = Column(DateTime, default=func.now())
    is_active = Column(Boolean, default=True)


class Score(Base):
    __tablename__ = "scores"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, index=True)
    attempts = Column(Integer)
    date = Column(Date, default=date.today)
    timestamp = Column(DateTime, default=func.now())
    won = Column(Boolean, default=False)
    guessed_word = Column(String, nullable=True)
    game_word = Column(String, nullable=False)


def get_db():
    """Dependency para obtener sesión de base de datos."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


# ============================================================================
# MODELOS PYDANTIC
# ============================================================================

class UserCreate(BaseModel):
    username: str = Field(..., min_length=3, max_length=20)
    password: str = Field(..., min_length=4, max_length=128)

    @validator('username')
    @classmethod
    def validate_username(cls, v: str) -> str:
        if not re.match(r'^[a-zA-Z0-9_]+$', v):
            raise ValueError('Username can only contain letters, numbers and underscores')
        return v.strip()


class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"


class TokenData(BaseModel):
    username: Optional[str] = None


class GuessRequest(BaseModel):
    guess: str
    current_game_word: str
    attempt_number: int = 1


# ============================================================================
# SEGURIDAD - JWT
# ============================================================================

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/token")


def create_access_token(data: dict, expires_delta: Optional[timedelta] = None) -> str:
    """Crea un token JWT con los datos proporcionados."""
    to_encode = data.copy()
    expire = datetime.now(timezone.utc) + (
        expires_delta or timedelta(minutes=15)
    )
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)


async def get_current_user(
    token: str = Depends(oauth2_scheme),
    db: Session = Depends(get_db)
) -> User:
    """Valida el token JWT y retorna el usuario actual."""
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username: str = payload.get("sub")
        if username is None:
            raise credentials_exception
        token_data = TokenData(username=username)
    except JWTError:
        raise credentials_exception

    user = db.query(User).filter(User.username == token_data.username).first()
    if user is None or not user.is_active:
        raise credentials_exception
    return user


# ============================================================================
# SEGURIDAD - RATE LIMITING
# ============================================================================

def check_rate_limit(ip: str) -> bool:
    """Verifica si una IP está bloqueada por muchos intentos fallidos."""
    if ip in failed_logins:
        attempts, lockout_time = failed_logins[ip]
        if datetime.now() < lockout_time:
            return False
        del failed_logins[ip]
    return True


def record_failed_login(ip: str):
    """Registra un intento fallido de login."""
    if ip not in failed_logins:
        failed_logins[ip] = [0, datetime.now()]
    failed_logins[ip][0] += 1
    if failed_logins[ip][0] >= MAX_FAILED_ATTEMPTS:
        failed_logins[ip][1] = datetime.now() + timedelta(seconds=LOCKOUT_TIME_SECONDS)


def clear_failed_login(ip: str):
    """Limpia el registro de intentos fallidos para una IP."""
    if ip in failed_logins:
        del failed_logins[ip]


# ============================================================================
# ENDPOINTS - AUTENTICACIÓN
# ============================================================================

@app.get("/")
async def root(request: Request) -> HTMLResponse:
    """Página principal del juego."""
    return templates.TemplateResponse("index.html", {"request": request})


@app.get("/health")
async def health_check() -> dict:
    """Endpoint para verificar el estado del servicio."""
    return {
        "status": "healthy",
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "words_loaded": len(VALID_WORDS)
    }


@app.post("/register")
async def register_user(
    user_data: UserCreate,
    db: Session = Depends(get_db)
) -> dict:
    """Registra un nuevo usuario."""
    # Verificar si existe
    db_user = db.query(User).filter(User.username == user_data.username).first()
    if db_user:
        raise HTTPException(status_code=400, detail="Username already exists")

    # Crear usuario
    hashed_password = get_password_hash(user_data.password)
    new_user = User(
        username=user_data.username,
        hashed_password=hashed_password,
        is_active=True
    )
    db.add(new_user)
    db.commit()
    db.refresh(new_user)

    return {
        "message": "User created successfully",
        "username": new_user.username
    }


@app.post("/token", response_model=Token)
async def login_for_access_token(
    request: Request,
    form_data: OAuth2PasswordRequestForm = Depends(),
    db: Session = Depends(get_db)
) -> dict:
    """Autentica usuario y retorna token JWT."""
    client_ip = request.client.host if request.client else "unknown"

    # Rate limiting
    if not check_rate_limit(client_ip):
        raise HTTPException(
            status_code=429,
            detail="Too many failed login attempts. Please try again later."
        )

    # Buscar usuario
    user = db.query(User).filter(User.username == form_data.username).first()

    if not user:
        record_failed_login(client_ip)
        raise HTTPException(status_code=401, detail="Usuario no encontrado")

    if not user.is_active:
        raise HTTPException(status_code=403, detail="User account is disabled")

    if not verify_password(form_data.password, user.hashed_password):
        record_failed_login(client_ip)
        raise HTTPException(status_code=401, detail="Contraseña incorrecta")

    # Login exitoso
    clear_failed_login(client_ip)

    access_token = create_access_token(
        data={"sub": user.username},
        expires_delta=timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    )
    
    return {"access_token": access_token, "token_type": "bearer"}


# ============================================================================
# ENDPOINTS - JUEGO
# ============================================================================

@app.get("/api/game/start")
async def start_game(
    request: Request,
    current_user: User = Depends(get_current_user)
) -> dict:
    """Inicia una nueva partida con una palabra aleatoria."""
    if not WORD_OF_DAY_POOL:
        raise HTTPException(status_code=500, detail="Word list not loaded")
    
    word = random.choice(WORD_OF_DAY_POOL).upper()
    return {"word": word, "message": "New game started"}


@app.post("/api/game/guess")
async def process_guess(
    request: Request,
    guess_req: GuessRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
) -> dict:
    """Procesa un intento del jugador."""
    today_word = guess_req.current_game_word.upper()
    guess = guess_req.guess.upper()

    # Validaciones
    if len(guess) != WORD_LENGTH:
        raise HTTPException(
            status_code=400,
            detail="La palabra debe tener 5 letras"
        )

    if guess not in VALID_WORDS:
        raise HTTPException(
            status_code=400,
            detail="Palabra no válida"
        )

    # Calcular resultado
    result = [""] * WORD_LENGTH
    word_remaining = list(today_word)

    # Primera pasada: letras correctas (verde)
    for i, letter in enumerate(guess):
        if letter == today_word[i]:
            result[i] = "correct"
            word_remaining[i] = None

    # Segunda pasada: letras presentes (amarillo) o ausentes (gris)
    for i, letter in enumerate(guess):
        if result[i] == "correct":
            continue
        if letter in word_remaining:
            result[i] = "present"
            word_remaining[word_remaining.index(letter)] = None
        else:
            result[i] = "absent"

    won = all(r == "correct" for r in result)

    # Guardar puntuación
    if won:
        new_score = Score(
            user_id=current_user.id,
            attempts=guess_req.attempt_number,
            won=True,
            guessed_word=guess,
            game_word=today_word
        )
        db.add(new_score)
        db.commit()
    elif guess_req.attempt_number >= MAX_ATTEMPTS:
        # Último intento fallido
        new_score = Score(
            user_id=current_user.id,
            attempts=guess_req.attempt_number,
            won=False,
            guessed_word=None,
            game_word=today_word
        )
        db.add(new_score)
        db.commit()

    return {"result": result, "won": won}


# ============================================================================
# ENDPOINTS - ESTADÍSTICAS
# ============================================================================

@app.get("/api/scores")
async def get_scores(
    request: Request,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
) -> List[dict]:
    """Obtiene el historial de partidas del usuario."""
    scores = db.query(Score).filter(
        Score.user_id == current_user.id
    ).order_by(
        Score.timestamp.desc()
    ).limit(50).all()
    
    return [{
        "id": s.id,
        "attempts": s.attempts,
        "date": s.date.isoformat(),
        "timestamp": s.timestamp.isoformat() if s.timestamp else None,
        "won": s.won,
        "guessed_word": s.guessed_word,
        "game_word": s.game_word
    } for s in scores]


@app.get("/api/stats")
async def get_stats(
    request: Request,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
) -> dict:
    """Obtiene estadísticas del usuario."""
    scores = db.query(Score).filter(
        Score.user_id == current_user.id
    ).all()
    
    total = len(scores)
    won = sum(1 for s in scores if s.won)
    lost = total - won
    
    return {
        "total_games": total,
        "won": won,
        "lost": lost,
        "win_percentage": round((won / total * 100), 1) if total > 0 else 0.0
    }


@app.delete("/api/scores/clear")
async def clear_scores(
    request: Request,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
) -> dict:
    """Elimina el historial de partidas del usuario."""
    db.query(Score).filter(
        Score.user_id == current_user.id
    ).delete()
    db.commit()
    
    return {"message": "Scores cleared"}


# ============================================================================
# MIDDLEWARE Y EXCEPTION HANDLERS
# ============================================================================

@app.middleware("http")
async def add_security_headers(request: Request, call_next):
    """Añade cabeceras de seguridad HTTP."""
    response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["X-XSS-Protection"] = "1; mode=block"
    return response


@app.exception_handler(HTTPException)
async def http_exception_handler(request: Request, exc: HTTPException):
    """Maneja excepciones HTTP de forma uniforme."""
    return JSONResponse(
        status_code=exc.status_code,
        content={"detail": exc.detail}
    )
