@echo off
REM ===========================================
REM WORDLE GAME - Script de Gestión para Windows (Batch)
REM ===========================================

setlocal enabledelayedexpansion

set COMPOSE_FILE=docker-compose.yml
set PROJECT_NAME=wordle

if "%1"=="" goto help
if "%1"=="start" goto start
if "%1"=="stop" goto stop
if "%1"=="restart" goto restart
if "%1"=="status" goto status
if "%1"=="logs" goto logs
if "%1"=="rebuild" goto rebuild
if "%1"=="clean" goto clean
if "%1"=="backup" goto backup
if "%1"=="restore" goto restore
if "%1"=="help" goto help
if "%1"=="--help" goto help
if "%1"=="-h" goto help

echo ❌ Comando desconocido: %1
goto help

:start
echo 🚀 Iniciando Wordle Game...
echo    🧹 Limpiando contenedores antiguos...
for /f "tokens=*" %%i in ('docker ps -a --filter name^=wordle --format "{{.Names}}" 2^>nul') do (
    docker rm -f %%i >nul 2>&1
)
docker compose -f %COMPOSE_FILE% up -d --build
echo ✅ ¡Juego iniciado!
echo.
echo 📱 Accede a: http://localhost
goto end

:stop
echo 🛑 Deteniendo Wordle Game...
docker compose -f %COMPOSE_FILE% down
echo ✅ ¡Juego detenido!
goto end

:restart
echo 🔄 Reiniciando Wordle Game...
docker compose -f %COMPOSE_FILE% restart
echo ✅ ¡Juego reiniciado!
goto end

:status
echo 📊 Estado del Wordle Game:
echo.
docker compose -f %COMPOSE_FILE% ps
echo.
echo 💾 Volúmenes:
docker volume ls | findstr wordle
if errorlevel 1 (
    echo   No se encontró ningún volumen
)
goto end

:logs
docker compose -f %COMPOSE_FILE% logs -f --tail=50
goto end

:rebuild
echo 🔨 Reconstruyendo imágenes...
docker compose -f %COMPOSE_FILE% down
docker compose -f %COMPOSE_FILE% up -d --build --force-recreate
echo ✅ ¡Imágenes reconstruidas!
goto end

:clean
echo ⚠️  LIMPIEZA COMPLETA - ¡Se perderán todos los datos!
set /p confirm="¿Estás seguro? (s/N): "
if /i "%confirm%"=="s" (
    docker compose -f %COMPOSE_FILE% down -v
    docker volume rm wordle_postgres_data 2>nul
    echo ✅ ¡Limpieza completada!
) else (
    echo ❌ Cancelado
)
goto end

:backup
for /f "tokens=2 delims==" %%a in ('wmic OS Get localdatetime ^| find "."') do set "dt=%%a"
set "timestamp=%dt:~0,8%_%dt:~8,6%"
set BACKUP_FILE=backups\wordle_backup_%timestamp%.sql

if not exist "backups" mkdir "backups"

echo 💾 Haciendo copia de seguridad...
docker exec wordle-db pg_dump -U wordleuser wordledb > %BACKUP_FILE%
echo ✅ ¡Copia creada: %BACKUP_FILE%
goto end

:restore
if "%2"=="" (
    echo ❌ Especifica el archivo de backup:
    echo    %0 restore backups\wordle_backup_20240101.sql
    exit /b 1
)
if not exist "%2" (
    echo ❌ El archivo no existe: %2
    exit /b 1
)
echo 🔄 Restaurando backup: %2
type %2 | docker exec -i wordle-db psql -U wordleuser wordledb
echo ✅ ¡Backup restaurado!
goto end

:help
echo.
echo 🎮 WORDLE GAME - Gestión de Contenedores
echo.
echo Uso: %0 ^<comando^>
echo.
echo Comandos disponibles:
echo   start       - Inicia el juego
echo   stop        - Detiene el juego
echo   restart     - Reinicia el juego
echo   status      - Muestra el estado
echo   logs        - Muestra los logs
echo   rebuild     - Reconstruye las imágenes
echo   clean       - Limpia todo (¡incluidos datos!)
echo   backup      - Hace copia de seguridad
echo   restore     - Restaura copia de seguridad
echo   help        - Muestra esta ayuda
echo.
echo Ejemplos:
echo   %0 start
echo   %0 logs
echo   %0 backup backups\wordle_backup_20240101.sql
echo.
goto end

:end
