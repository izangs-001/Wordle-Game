# WORDLE GAME - Script de Inicio Optimizado
# ===========================================

Write-Host "WORDLE GAME - Iniciando..." -ForegroundColor Cyan

# Verificar Docker
try {
    docker info | Out-Null
    Write-Host "[OK] Docker listo" -ForegroundColor Green
} catch {
    Write-Host "ERROR: Docker no esta ejecutandose" -ForegroundColor Red
    exit 1
}

# Crear .env si no existe
if (-not (Test-Path ".env")) {
    @"
POSTGRES_DB=wordledb
POSTGRES_USER=wordleuser
POSTGRES_PASSWORD=wordlepassword
DB_PORT=5432
WEB_PORT=80
SECRET_KEY=09d25e094faa6ca2556c818166b7a9563b93f7099f6f0f4a27521796c342f561
ENVIRONMENT=production
"@ | Out-File -FilePath ".env" -Encoding UTF8
    Write-Host "[OK] .env creado" -ForegroundColor Green
}

# Crear directorios necesarios
"backups", "data" | ForEach-Object {
    if (-not (Test-Path $_)) { New-Item -ItemType Directory -Path $_ | Out-Null }
}

# Limpiar contenedores antiguos
Write-Host "Limpiando contenedores antiguos..." -ForegroundColor Yellow
docker rm -f wordle-db wordle-backend 2>$null | Out-Null

# Iniciar contenedores
Write-Host "Iniciando contenedores optimizados..." -ForegroundColor Cyan
docker compose up -d --build --remove-orphans

Write-Host ""
Write-Host "Esperando servicios..." -ForegroundColor Yellow
Start-Sleep -Seconds 15

# Mostrar estado
Write-Host ""
Write-Host "======================================" -ForegroundColor Cyan
docker compose ps
Write-Host "======================================" -ForegroundColor Cyan

# Verificar health
try {
    $r = Invoke-WebRequest -Uri "http://localhost/health" -TimeoutSec 5 -UseBasicParsing
    if ($r.StatusCode -eq 200) {
        Write-Host "WORDLE GAME OPTIMIZADO - LISTO" -ForegroundColor Green
        Write-Host "Accede: http://localhost" -ForegroundColor Cyan
        Write-Host ""
        Write-Host "Optimizaciones:" -ForegroundColor Yellow
        Write-Host "  - Memoria: 448MB (antes 768MB)" -ForegroundColor Gray
        Write-Host "  - Health checks: 2x mas rapidos" -ForegroundColor Gray
        Write-Host "  - Build cache: habilitada" -ForegroundColor Gray
        Write-Host "  - PostgreSQL: optimizado" -ForegroundColor Gray
    }
} catch {
    Write-Host "Servicios iniciando... verifica: docker compose ps" -ForegroundColor Yellow
}
Write-Host ""
