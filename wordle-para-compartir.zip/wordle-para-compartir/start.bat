@echo off
REM ===========================================
REM WORDLE GAME - Script de Inicio para Windows (Batch)
REM Limpia contenedores antiguos e inicia sin errores
REM ===========================================

echo.
echo 🎮 WORDLE GAME - Iniciando juego...
echo ======================================
echo.

REM 1. Verificar Docker
echo 📦 Verificando Docker...
docker info >nul 2>&1
if errorlevel 1 (
    echo ❌ ERROR: Docker no está ejecutándose
    echo    Inicia Docker Desktop primero
    pause
    exit /b 1
)
echo ✅ Docker está ejecutándose
echo.

REM 2. Verificar .env
echo ⚙️  Verificando configuración...
if not exist ".env" (
    echo    ⚠️  .env no existe, creando...
    (
        echo PROJECT_NAME=wordle
        echo POSTGRES_DB=wordledb
        echo POSTGRES_USER=wordleuser
        echo POSTGRES_PASSWORD=wordlepassword
        echo DB_PORT=5432
        echo WEB_PORT=80
        echo SECRET_KEY=09d25e094faa6ca2556c818166b7a9563b93f7099f6f0f4a27521796c342f561
        echo ENVIRONMENT=production
    ) > ".env"
    echo    ✅ .env creado
) else (
    echo    ✅ .env encontrado
)
echo.

REM 3. Crear directorios
echo 📁 Verificando directorios...
if not exist "backups" mkdir "backups"
echo    ✅ Directorios listos
echo.

REM 4. Limpiar contenedores antiguos
echo 🧹 Limpiando contenedores antiguos...
for /f "tokens=*" %%i in ('docker ps -a --filter name^=wordle --format "{{.Names}}" 2^>nul') do (
    echo    Eliminando: %%i
    docker rm -f %%i >nul 2>&1
)
echo    ✅ Limpieza completada
echo.

REM 5. Iniciar contenedores
echo 🚀 Iniciando contenedores...
echo    (Esto puede tardar unos minutos la primera vez)
echo.
docker compose up -d --build

if errorlevel 1 (
    echo.
    echo ❌ ERROR al iniciar los contenedores
    echo    Ejecuta 'docker compose logs' para ver detalles
    pause
    exit /b 1
)

echo.
echo ⏳ Esperando a que los servicios estén listos...
timeout /t 10 /nobreak >nul

echo.
echo ======================================
echo 📊 Estado final:
docker compose ps --format "table {{.Name}}\t{{.Status}}\t{{.Ports}}"
echo.
echo ======================================
echo 🎉 ¡WORDLE GAME LISTO PARA USAR!
echo ======================================
echo.
echo 📱 Accede al juego: http://localhost
echo.
echo 📋 Comandos útiles:
echo    wordle.bat status   - Ver estado
echo    wordle.bat logs     - Ver logs
echo    wordle.bat stop     - Detener juego
echo    wordle.bat clean    - Limpiar todo
echo.
pause
